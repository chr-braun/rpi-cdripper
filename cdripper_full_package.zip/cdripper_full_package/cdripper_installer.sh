#!/bin/bash
# Installer-Skript